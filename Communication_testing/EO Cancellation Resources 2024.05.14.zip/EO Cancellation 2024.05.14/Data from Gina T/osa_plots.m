%osa plotting 

clear all 
close all

data1 = load("osa_min_linewidth_filter1.mat");
data2 = load("osa_min_linewidth_filter2.mat");

power1 = data1.P_OSA;
power2 = data2.P_OSA;

wl1 = data1.WL_OSA*1e+9;
wl2 = data2.WL_OSA*1e+9;

for i = 1:length(power1)
    if power1(i) <= -80
        power1(i) = -80;
    end
    if power2(i) < -80
        power2(i) = -80;
    end 
end 
figure(1) 
hold on 
plot(wl1,power1,"DisplayName",'Filter 1')
title("Minimum Bandwidth Spectrum of Filter 1")
xlabel("Wavelength (nm)")
ylabel("Transmission (dBm)")
hold off


figure(2) 
hold on 
plot(wl2,power2,"DisplayName",'Filter 2')
title("Minimum Bandwidth Spectrum of Filter 2")
xlabel("Wavelength (nm)")
ylabel("Transmission (dBm)")
hold off