%osa plotting 

clear all 
close all

fBin = 3.65e9;              % Bin spacing [Hz].
data1 = load("osa_lossy_min_linewidth_filter1.mat");
data2 = load("osa_lossy_min_linewidth_filter2.mat");

power1 = 10.^(data1.P_OSA/10)*1e-3;         % Power in [W] + flip.
power2 = 10.^(data2.P_OSA/10)*1e-3;

power1 = power1/max(power1);
power2 = power2/max(power2);

c = 299792458;
f1 = c./data1.WL_OSA;
f2 = c./data2.WL_OSA;

ii1 = find(power1==max(power1));
ii2 = find(power2==max(power2));

% for i = 1:length(power1)
%     if power1(i) <= -80
%         power1(i) = -80;
%     end
%     if power2(i) < -80
%         power2(i) = -80;
%     end 
% end 
figure(1) 
hold on 
plot((f1-f1(ii1))*1e-9,power1,"DisplayName",'Filter 1','LineWidth',2)
plot((f1-f1(ii1)-fBin)*1e-9,power1,"DisplayName",'Filter 1','LineWidth',2)
plot((f1-f1(ii1)+fBin)*1e-9,power1,"DisplayName",'Filter 1','LineWidth',2)
title("Minimum Bandwidth Spectrum of Filter 1")
xlabel('Frequency Offset [GHz]')
ylabel("Transmission")
set(gca,'FontName','Arial','FontSize',18,'LineWidth',2)
axis([-10 10 0 1])
hold off; box on;


figure(2) 
hold on 
plot((f2-f2(ii2))*1e-9,power2,"DisplayName",'Filter 2','LineWidth',2)
plot((f2-f2(ii2)-fBin)*1e-9,power2,"DisplayName",'Filter 2','LineWidth',2)
plot((f2-f2(ii2)+fBin)*1e-9,power2,"DisplayName",'Filter 2','LineWidth',2)
title("Minimum Bandwidth Spectrum of Filter 2")
xlabel('Frequency Offset [GHz]')
ylabel("Transmission")
set(gca,'FontName','Arial','FontSize',18,'LineWidth',2)
axis([-10 10 0 1])
hold off; box on;