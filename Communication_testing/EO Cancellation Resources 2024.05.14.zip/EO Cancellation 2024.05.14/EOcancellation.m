function EOcancellation
% This function explores the impact of filter crosstalk on a modulation
% cancellation experiment a la Harris [PRL 103, 163601 (2009)]. What
% happens when the observation filters have linewidths comparable to
% modulation frequency?

% JML
% 2023.08.23
% +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ %

%% CONSTANTS
j = 0;              % Fixed filter location.
K = 10;             % Shift for tunable filter.
M = 50;             % Number of terms in Bessel summation.
P = 10;             % Number of shifts for crosstalk calculation.
DEL = pi;          % Modulation index considered.
F = 1.51;          % Separability fraction (mod. freq. over Gaussian filter FWHM).

%% INDICES
k = (-K:1:K).';
m = (-M:1:M).';
p = (-P:1:P).';

%% CROSSTALK CALCULATION
G = exp(-2*log(2)*(F*p).^2);           % Crosstalk function.

% CASE: DELa=DELb=phiA=phiB=0
R1 = abs(psi(k,p,0,0,0,0)).^2*G;       % Coincidences as function of k.

% CASE: DELa=DEL, DELb=phiA=phiB=0
R2 = abs(psi(k,p,DEL,0,0,0)).^2*G;

% CASE: DELa=DELb=DEL, phiA=phiB=0
R3 = abs(psi(k,p,DEL,DEL,0,0)).^2*G;

% CASE: DELa=DELb=DEL, phiA=0, phiB=pi
R4 = abs(psi(k,p,DEL,DEL,0,pi)).^2*G;



figure
subplot(2,2,1)
stem(k,R1,'LineWidth',2,'Marker','none')
set(gca,'FontName','Arial','FontSize',18,'LineWidth',1.5)
axis([-K K 0 1])
ylabel('Coincidence Rate')
subplot(2,2,2)
stem(k,R2,'LineWidth',2,'Marker','none')
set(gca,'FontName','Arial','FontSize',18,'LineWidth',1.5)
axis([-K K 0 1])
subplot(2,2,3)
stem(k,R3,'LineWidth',2,'Marker','none')
set(gca,'FontName','Arial','FontSize',18,'LineWidth',1.5)
axis([-K K 0 1])
xlabel('Filter Index k')
ylabel('Coincidence Rate')
subplot(2,2,4)
stem(k,R4,'LineWidth',2,'Marker','none')
set(gca,'FontName','Arial','FontSize',18,'LineWidth',1.5)
axis([-K K 0 1])
xlabel('Filter Index k')


figure
subplot(2,2,1)
stem(k,R1,'LineWidth',2,'Marker','none')
set(gca,'FontName','Arial','FontSize',18,'LineWidth',1.5,'YScale','log')
axis([-K K 1e-4 1])
ylabel('Coincidence Rate')
subplot(2,2,2)
stem(k,R2,'LineWidth',2,'Marker','none')
set(gca,'FontName','Arial','FontSize',18,'LineWidth',1.5,'YScale','log')
axis([-K K 1e-4 1])
subplot(2,2,3)
stem(k,R3,'LineWidth',2,'Marker','none')
set(gca,'FontName','Arial','FontSize',18,'LineWidth',1.5,'YScale','log')
axis([-K K 1e-4 1])
xlabel('Filter Index k')
ylabel('Coincidence Rate')
subplot(2,2,4)
stem(k,R4,'LineWidth',2,'Marker','none')
set(gca,'FontName','Arial','FontSize',18,'LineWidth',1.5,'YScale','log')
axis([-K K 1e-4 1])
xlabel('Filter Index k')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% SUB-ROUTINE
function z = psi(k,p,DELa,DELb,phiA,phiB)
% Computes wavepacket over k and p indexes for a specific combination of
% modulation indexes and phases.
    z = zeros(2*K+1,2*P+1);               % Initial wavepackt over (k,p) values.
    Ja = besselj(m,DELa);
    for ii = 1:2*K+1
        for jj = 1:2*P+1
            Jb = besselj(j+k(ii)-m+p(jj),DELb);
            z(ii,jj) = sum(Ja.*Jb.*exp(-1i*m*(phiA-phiB)));
        end
    end
end

end